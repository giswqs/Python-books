See /osgeopy-data/Landsat/Washington/simple_example.vrt
